# 地域略称を一意の数値にマッピング
unique_locations <- unique(data)
location_indices <- match(data, unique_locations)

# 行列の作成
nrow <- 3
ncol <- length(location_indices) / nrow
if (ncol != floor(ncol)) {
  ncol <- floor(ncol)
  location_indices <- location_indices[1:(nrow * ncol)]
}
x <- matrix(location_indices, nrow = nrow, byrow = TRUE)

# フィッシャーの正確確率検定の実行
library(stats)
test_result <- fisher.test(x, simulate.p.value=TRUE)
print(test_result)




clusters1 <- list(
  c('W', 'S', 'W', 'W', 'W', 'W', 'S', 'W', 'NE', 'NE', 'W', 'S', 'W', 'W', 'NE', 'S', 'S', 'S', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'MW', 'W', 'W'),
  c('W', 'NE', 'MW', 'W', 'W', 'NE', 'W', 'W', 'W', 'MW', 'S', 'SLO', 'MW', 'NE', 'W', 'W', 'MW', 'W', 'S', 'NE', 'W', 'S', 'MW'),
  c('S', 'SPA', 'GER', 'UK', 'NE', 'S', 'NE', 'W', 'S', 'W', 'W', 'W', 'NE', 'W', 'W', 'MW', 'W', 'S', 'W', 'W', 'W', 'S', 'W', 'W', 'NE', 'W', 'NE', 'S', 'W', 'UK', 'W', 'MW', 'W', 'NE', 'MW', 'NED', 'S', 'W', 'SWE', 'JAM', 'NOR', 'W', 'W', 'W', 'S', 'NE', 'W', 'CAN', 'W', 'W', 'W', 'W', 'W', 'NE', 'S', 'W', 'MW', 'W', 'W', 'NE', 'W', 'W', 'W', 'CAN', 'W', 'UK', 'W', 'W', 'SPA', 'NE', 'W', 'W', 'W', 'W', 'W', 'S', 'W', 'S', 'W', 'W', 'W', 'S', 'W', 'W', 'W', 'UK', 'W', 'ITA', 'NE', 'S', 'W', 'S', 'S', 'S', 'W', 'S', 'W', 'NE', 'CAN', 'W', 'W', 'W', 'AZE', 'NE', 'S', 'NE', 'S', 'S', 'W', 'MW', 'W', 'W', 'W', 'W', 'W', 'MW', 'S', 'NE/W', 'FRA', 'W', 'CAN', 'W', 'W', 'S', 'W', 'W', 'MW', 'W', 'S', 'S', 'S', 'W', 'W'),
  c('NE', 'NE', 'NE', 'S', 'NE', 'NE', 'NE', 'NE', 'S', 'S', 'S', 'NE', 'NE', 'W', 'S', 'S', 'NE', 'W', 'NE', 'S', 'NE', 'S', 'NE', 'NE', 'NE', 'NE', 'NE', 'NE', 'MW', 'S', 'S', 'NE', 'MW', 'W', 'S', 'NE', 'S', 'NE', 'BAR', 'NE', 'S', 'NE', 'NE', 'W', 'NE', 'NE', 'NE', 'JAM'),
  c('W'),
  c('NE', 'S', 'NE', 'UK', 'NE', 'MW', 'NE', 'W', 'NE', 'W', 'NE', 'MW', 'MW', 'S', 'NE', 'NE', 'NE', 'W', 'S', 'S', 'S', 'NE', 'CAN', 'UK', 'NE', 'NE', 'NE', 'W', 'UK', 'W', 'NE', 'JPN', 'W', 'SWE', 'S', 'NE', 'S', 'MW', 'NE', 'NE', 'NE', 'NE', 'S', 'NE', 'NE', 'NE', 'MW', 'NE', 'W', 'MW', 'NE', 'NE', 'NE', 'NE', 'NE', 'NE', 'NE', 'W', 'MW', 'NE'),
  c('S', 'NE', 'MW', 'NE', 'CHE', 'NE', 'NE', 'MW', 'NE', 'W', 'NE', 'NE', 'UK', 'ISL', 'NE', 'NE', 'NE', 'NE', 'NOR', 'NE', 'W', 'NE', 'NE', 'JPN', 'NE', 'NE', 'NE', 'W', 'NE', 'RUS', 'S', 'NE', 'NE', 'NE', 'NE', 'NE', 'NE', 'NE', 'W', 'NE', 'W', 'S', 'S', 'S', 'S', 'NE', 'NE', 'NE', 'S', 'S', 'NE', 'S'),
  c('W', 'W'),
  c('S', 'NE', 'UK', 'NE', 'W', 'UK', 'MW', 'MW', 'NE', 'MW', 'NE', 'W', 'NE', 'NE', 'S', 'S', 'NE', 'NE', 'S', 'S', 'NE', 'CAN', 'NE', 'S', 'SWE', 'MW', 'W', 'W', 'NE', 'UK', 'S', 'NE', 'MW', 'S', 'MW', 'NE', 'NE', 'W', 'NE', 'NE', 'S', 'S', 'CAN', 'CAN', 'S', 'NE', 'S', 'S', 'S', 'W', 'BAR', 'S', 'JPN', 'NE', 'NE', 'MW', 'S', 'S', 'W', 'NE', 'S', 'NE', 'NE', 'CAN', 'NE', 'MW', 'W', 'NE', 'NE', 'MW', 'W', 'MW', 'MW', 'W', 'NE', 'W', 'MW', 'S', 'MW', 'MW', 'UK', 'MW', 'MW', 'NE', 'NE', 'NE', 'S', 'MW', 'MW', 'NE', 'UK', 'S', 'MW', 'S'),
  c('MW'),
  c('W', 'MW', 'NE', 'NE', 'W', 'NE', 'NE', 'NE', 'NE', 'NE', 'NE', 'MW', 'UK', 'W', 'W', 'NE', 'CAN', 'NE', 'NE', 'NE', 'NE', 'UK', 'NE', 'S', 'NE', 'S', 'NE', 'NE', 'NE', 'NE'),
  c('GER', 'GER', 'GER'),
  c('NE', 'W', 'NE', 'NE', 'NE', 'NE', 'NE', 'MW', 'NE', 'NE', 'NE', 'NE', 'NE', 'NE', 'NE', 'S', 'NE', 'NE', 'NE', 'UK', 'NE', 'MW', 'NE', 'NE', 'NE', 'NE', 'W', 'NE', 'NE'),
  c('W', 'W'),
  c('NE', 'NE', 'S', 'NE', 'NE', 'S', 'S', 'S', 'NE', 'NE', 'NE', 'NE', 'NE', 'W', 'W', 'W', 'NE', 'NE', 'NE', 'S', 'S', 'NE', 'JAM', 'NE', 'MW', 'NE', 'NE', 'W', 'S', 'NE', 'S', 'S', 'NE', 'NE', 'NE'),
  c('NE', 'UK'),
  c('S'),
  c('NE'),
  c('NE', 'MW'),
  c('NE', 'W', 'MW', 'MW', 'S', 'W', 'W', 'W', 'S', 'W', 'W', 'W', 'W', 'W', 'S', 'W', 'W', 'W', 'W', 'NE', 'NE', 'NE', 'W', 'W', 'NE', 'NE', 'W', 'W', 'W', 'S', 'S', 'W', 'NE', 'W', 'NE', 'W'),
  c('NE', 'UK')
)

unique_locations <- unique(unlist(clusters1))

# 行列を作成（各クラスタの各地域の出現回数をカウント）
matrix_data <- sapply(clusters1, function(cluster) {
  tab <- table(factor(cluster, levels = unique_locations))
  if(length(tab) < length(unique_locations)) {
    tab <- c(tab, rep(0, length(unique_locations) - length(tab)))
  }
  return(tab)
})

# 行列を転置（地域×クラスタの形式にする）
x <- t(matrix_data)
colnames(x) <- unique_locations

# フィッシャー検定の実行
if(dim(x)[1] == 2) {
  # 2x2の場合は通常のフィッシャー検定を使用
  test_result <- fisher.test(x)
} else {
  # 3x3以上の場合は、Monte Carloシミュレーションを使用
  test_result <- fisher.test(x, simulate.p.value = TRUE, B = 10000)
}

# 結果の出力
print(test_result)


# クラスタデータを個別のリストとして整理
clusters2 <- list(
  c('W', 'W', 'S', 'W', 'W', 'W', 'NE', 'W', 'NE', 'NE', 'MW', 'W', 'W', 'UK', 'UK', 'MW', 'NE', 'W', 'W', 'W', 'UK', 'NE', 'MW', 'W', 'W', 'W', 'W', 'W', 'JPN', 'W', 'W', 'NE', 'MW', 'MW', 'NE', 'MW', 'W', 'AUS/NE', 'MW', 'AUS', 'NE', 'W', 'MW', 'MW', 'W/NE', 'W', 'AUS', 'W', 'S', 'UK', 'W', 'UK', 'W', 'S', 'S', 'W', 'NE', 'W', 'W', 'NE', 'W', 'UK', 'MW', 'W', 'W', 'NE', 'UK', 'NE', 'MW', 'S', 'NE', 'UK', 'W', 'UK', 'W', 'NE'),
  c('W/NE', 'W/NE', 'W', 'NE', 'S', 'MW', 'W', 'S', 'W', 'W', 'W', 'MW', 'MW', 'W', 'W', 'GER', 'CAN', 'W', 'W', 'UK', 'S', 'W', 'NE', 'W', 'S', 'MW', 'NE', 'MW', 'NOR', 'S', 'S', 'S', 'S/MW', 'W', 'MW', 'W', 'W', 'W', 'S', 'S', 'MW', 'W', 'W', 'multi  place', 'S', 'MW', 'NE', 'S', 'W', 'S', 'MW', 'W', 'W', 'W', 'W', 'W', 'W', 'CAN', 'W', 'S', 'W', 'S', 'NOR', 'S', 'MW', 'GER', 'NE', 'S', 'NE', 'S', 'W', 'NE', 'MW', 'NE', 'W', 'S', 'NL', 'S', 'S', 'W', 'S', 'NE', 'W', 'W', 'AUS', 'NE', 'S', 'W', 'W', 'CHE', 'MW', 'W', 'W', 'W', 'NOR', 'MW', 'S', 'S', 'W', 'MW', 'UK', 'W', 'S', 'W', 'CAN', 'NOR', 'W', 'MW', 'S', 'W/NE', 'W', 'W', 'S', 'W', 'W', 'UK', 'NE', 'W', 'S', 'S', 'UK', 'CAN', 'S', 'W', 'W', 'W', 'W', 'CAN', 'W', 'S', 'W', 'CAN', 'W', 'W/S/NE', 'S', 'NE', 'UK', 'S'),
  c('KR', 'W', 'S', 'CAN', 'CHE', 'W', 'CAN', 'W', 'S', 'W', 'W', 'W', 'S', 'W', 'W/NE', 'W', 'W', 'W', 'W', 'NE', 'W/MW', 'W', 'W', 'W', 'W', 'MW', 'W', 'W', 'W', 'NE', 'W', 'S', 'S', 'W', 'NE', 'CAN', 'W', 'NE', 'MW', 'W', 'NE', 'W/NE/S', 'W/NE', 'W', 'W', 'W', 'W', 'MW', 'AUS', 'UK', 'W', 'W', 'W', 'W', 'S', 'UK', 'W/S'),
  c('W', 'W', 'UK', 'UK', 'UK', 'W', 'W', 'W', 'UK', 'S', 'S', 'UK', 'MW', 'S', 'UK', 'UK', 'NE', 'S', 'W', 'UK', 'MW', 'S', 'W', 'S', 'UK', 'UK', 'S', 'W', 'CN', 'S'),
  c('UK', 'MW', 'S', 'S', 'W/NE', 'S', 'S', 'NE', 'W', 'W', 'W/S', 'CAN', 'W', 'NE', 'S', 'W', 'W', 'S', 'W', 'W', 'W', 'MW', 'W', 'UK', 'UK', 'W', 'NLD', 'W', 'W', 'BRA', 'W', 'W', 'W', 'MW', 'NE'),
  c('W', 'W', 'W', 'W', 'W', 'W', 'MW', 'MW', 'AUT', 'W', 'MW', 'S', 'NE', 'MW', 'NE', 'MW', 'MW', 'W', 'W', 'W', 'W', 'MW', 'NE', 'NE'),
  c('MW', 'NOR', 'W', 'S', 'W', 'W', 'W', 'S', 'W', 'NOR', 'S', 'W', 'NOR', 'W', 'NOR', 'NOR', 'NOR', 'W', 'NOR', 'S', 'S', 'NOR', 'NOR', 'W', 'S', 'NOR', 'GER', 'S', 'NE', 'W', 'S', 'W', 'NE'),
  c('NOR', 'NOR', 'W', 'S', 'NOR', 'S', 'NL', 'NOR', 'NOR', 'S', 'NOR', 'NE', 'NOR', 'W', 'MW', 'W', 'NOR', 'NOR', 'NOR', 'NOR', 'NOR', 'NOR', 'MW', 'W', 'NE'),
  c('W', 'W', 'W', 'W', 'MW', 'W', 'W', 'NE', 'MW', 'NE', 'S', 'W', 'MW', 'MW', 'S', 'W', 'S', 'W', 'W', 'W', 'S', 'W', 'W', 'NE', 'W', 'W', 'MW', 'W', 'W', 'MW', 'W', 'W', 'CAN', 'W', 'S', 'S', 'W', 'MW', 'S', 'S', 'W', 'W', 'W', 'NE', 'W', 'NE', 'S', 'W', 'MW', 'NE', 'NE', 'W', 'W', 'NE', 'MW'),
  c('W', 'W/S', 'MW/W', 'W', 'W', 'NOR', 'NE', 'MW', 'S', 'MW', 'W/NE', 'W', 'CAN', 'S', 'W', 'W', 'SWE', 'W', 'W', 'MW', 'W', 'NE', 'MW', 'W', 'W', 'W', 'W', 'S', 'W', 'W', 'S', 'S', 'W', 'S', 'W', 'MW', 'NE', 'W', 'W', 'W', 'MW', 'MW', 'NE', 'W', 'W', 'W', 'S', 'W', 'AUS', 'S', 'W', 'S', 'W', 'W', 'W', 'MW', 'S', 'NE', 'W', 'W', 'S', 'NOR', 'S', 'W', 'W', 'MW', 'S', 'W', 'MW', 'MW', 'NE', 'MW', 'AUS', 'W', 'W', 'MW', 'W', 'W', 'W', 'W', 'W', 'W', 'FR', 'NE', 'W', 'W', 'S', 'W', 'MW', 'W', 'W', 'GER', 'NZ', 'W', 'W', 'W', 'NE', 'MW', 'S', 'MW', 'NE', 'MW', 'S', 'GER', 'AUS', 'W', 'W', 'MW', 'SWE', 'W', 'MW', 'MW', 'MW', 'MW/NE', 'W', 'NE', 'W', 'S', 'W', 'W', 'W', 'W', 'W', 'W/NE/S', 'MW/W', 'W', 'W', 'W', 'W', 'MW'),
  c('W', 'W', 'W', 'W', 'W', 'S', 'W', 'W', 'S', 'W', 'TTO', 'NE', 'MW', 'MW', 'S', 'W', 'NE', 'S', 'NE', 'S', 'W', 'W', 'W', 'W', 'CAN', 'MW', 'W/NE/MW/S', 'S', 'MW', 'UK', 'W', 'S'),
  c('W', 'W', 'W', 'W', 'W', 'W', 'NE', 'W', 'NW', 'EU', 'NE', 'W', 'S', 'NLD', 'S', 'S', 'S', 'W/NE', 'S', 'NE', 'MW', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'S', 'W', 'S'),
  c('MW')
)


all_locations <- unique(unlist(clusters2))

# 地域名を含む行列を作成するための関数
create_matrix <- function(cluster_list) {
  location_counts <- sapply(cluster_list, function(cluster) {
    table(factor(cluster, levels = all_locations))
  })
  
  # 地域名とクラスタ名を含む行列を生成
  location_matrix <- matrix(unlist(location_counts), nrow = length(all_locations), byrow = TRUE)
  dimnames(location_matrix) <- list(all_locations, paste("Cluster", seq_along(cluster_list)))
  return(location_matrix)
}

# 行列を作成
location_matrix <- create_matrix(clusters2)

# フィッシャー検定を実行
test_result <- fisher.test(location_matrix, simulate.p.value=TRUE)

# 結果の出力
print(test_result)

# 地域の一覧を準備
regions <- c('NE', 'S', 'MW', 'W', 'NW', 'AUS', 'AUS/NE', 'JPN', 'UK', 'NL', 'CN', 'CAN', 'W/NE', 'KR', 'CHE', 'W/S', 'W/NE/S', 'W/MW', 'AUT', 'TTO', 'W/NE/MW/S', 'NOR', 'NLD', 'BRA', 'EU', 'GER', 'FR', 'SWE', 'MW/W', 'MW/NE', 'NZ', 'W/S/NE', 'S/MW', 'multi  place', 'POR', 'S/NE', 'JAM', 'RUS', 'NED', 'SPA', 'BAR', 'ITA', 'ISL', 'AZE', 'SLO', 'FRA', 'NE/W')

group1 <- unlist(clusters1)
group2 <- unlist(clusters2)

# 頻度表の作成
table1 <- table(factor(group1, levels = regions))
table2 <- table(factor(group2, levels = regions))

# クロス表の作成
cross_table2 <- rbind(table1, table2)

# カイ二乗検定の実行
chi_result <- chisq.test(cross_table)

# フィッシャーの正確検定の実行（データが少ない場合）
fisher_result2 <- fisher.test(cross_table2, simulate.p.value=TRUE)

# 結果の出力
print(cross_table2)
print(fisher_result2)


clusters3 <- c('W', 'MW', 'W', 'NE', 'NE', 'MW', 'MW', 'W', 'S', 'S', 'UK', 'NE', 'NE', 'W', 'NE', 'NE', 'NE', 'NE', 'W', 'NE', 'W', 'MW', 'S', 'W', 'NE', 'NE', 'S', 'S', 'NE', 'W', 'NE', 'MW', 'NE', 'S', 'NE', 'W', 'MW', 'S', 'W', 'NE', 'NE', 'W', 'W', 'NE', 'S', 'W', 'S', 'W', 'NE', 'CAN', 'S', 'NE', 'SWE', 'NE', 'NE', 'W', 'W', 'W', 'CAN', 'MW', 'S', 'S', 'W', 'W', 'NE', 'S', 'NE', 'NE', 'W', 'S', 'MW', 'W', 'NE', 'NE', 'MW', 'W', 'JPN', 'S', 'W', 'S', 'UK', 'W', 'UK', 'NE', 'CAN', 'S', 'S', 'W', 'W', 'NE', 'MW', 'MW', 'NE', 'W', 'S', 'W', 'W', 'W', 'NE', 'W', 'W', 'CAN', 'NE', 'NE', 'S', 'W', 'W', 'W', 'W', 'NE', 'MW', 'W', 'NE', 'W', 'NE', 'W', 'S', 'W', 'W', 'NE', 'W', 'NE', 'UK', 'W', 'UK', 'W', 'S', 'NE', 'NE', 'NE', 'W', 'NE', 'W', 'NE', 'NE', 'W', 'MW', 'NE', 'W', 'W', 'MW', 'S', 'MW', 'W', 'S', 'W', 'JAM', 'NE', 'W', 'S', 'NE', 'NE', 'NE', 'NE', 'S', 'NE', 'W', 'W', 'S', 'NE', 'S', 'W', 'NE', 'MW', 'NE', 'S', 'NE', 'NE', 'RUS', 'S', 'S', 'W', 'S', 'NE', 'JPN', 'S', 'NE', 'W', 'S', 'NE', 'NE', 'W', 'NE', 'NE', 'S', 'W', 'NE', 'NE', 'NE', 'W', 'NE', 'NE', 'MW', 'UK', 'S', 'NE', 'NE', 'CAN', 'S', 'S', 'NED', 'S', 'W', 'MW', 'NE', 'S', 'MW', 'W', 'W', 'NE', 'CAN', 'NE', 'NE', 'NE', 'NE', 'NE', 'W', 'MW', 'W', 'MW', 'NE', 'W', 'W', 'NE', 'NE', 'NE', 'S', 'UK', 'S', 'NE', 'NE', 'GER', 'NE', 'S', 'W', 'S', 'W', 'NE', 'W', 'MW', 'W', 'UK', 'W', 'MW', 'NE', 'S', 'SPA', 'W', 'NE', 'W', 'NE', 'W', 'NE', 'W', 'NE', 'NE', 'NE', 'S', 'NE', 'W', 'W', 'NE', 'S', 'W', 'MW', 'S', 'BAR', 'W', 'NE', 'NE', 'MW', 'NE', 'W', 'W', 'W', 'NE', 'GER', 'S', 'NE', 'NE', 'W', 'W', 'NE', 'NE', 'NE', 'NE', 'W', 'W', 'S', 'S', 'S', 'NE', 'CAN', 'NE', 'NE', 'GER', 'NE', 'ITA', 'W', 'W', 'NOR', 'NE', 'NE', 'NOR', 'W', 'NE', 'NE', 'W', 'S', 'S', 'NE', 'W', 'NE', 'MW', 'W', 'S', 'JAM', 'NE', 'NE', 'W', 'W', 'S', 'W', 'NE', 'NE', 'SWE', 'S', 'W', 'S', 'W', 'MW', 'CHE', 'NE', 'NE', 'W', 'NE', 'NE', 'W', 'MW', 'NE', 'NE', 'NE', 'W', 'S', 'NE', 'W', 'W', 'NE', 'NE', 'S', 'S', 'W', 'S', 'W', 'NE', 'W', 'NE', 'CAN', 'W', 'NE', 'MW', 'NE', 'MW', 'W', 'S', 'W', 'NE', 'NE', 'NE', 'W', 'BAR', 'S', 'S', 'NE', 'NE', 'NE', 'NE', 'W', 'W', 'MW', 'MW', 'S', 'NE', 'JPN', 'W', 'UK', 'W', 'MW', 'NE', 'NE', 'S', 'NE', 'NE', 'NE', 'W', 'NE', 'NE', 'NE', 'NE', 'NE', 'W', 'S', 'W', 'NE', 'NE', 'NE', 'W', 'W', 'W', 'S', 'NE', 'MW', 'NE', 'MW', 'MW', 'ISL', 'NE', 'NE', 'S', 'MW', 'S', 'S', 'NE', 'UK', 'W', 'W', 'S', 'W', 'NE', 'NE', 'NE', 'S', 'W', 'W', 'AZE', 'W', 'W', 'NE', 'NE', 'MW', 'W', 'W', 'W', 'SWE', 'NE', 'W', 'S', 'NE', 'UK', 'SLO', 'W', 'UK', 'S', 'CAN', 'GER', 'NE', 'S', 'MW', 'NE', 'MW', 'S', 'S', 'W', 'NE', 'S', 'W', 'W', 'S', 'CAN', 'MW', 'W', 'S', 'S', 'MW', 'S', 'NE', 'UK', 'W', 'NE', 'S', 'UK', 'W', 'S', 'MW', 'MW', 'NE', 'S', 'NE', 'NE', 'W', 'NE', 'S', 'NE', 'UK', 'W', 'W', 'NE', 'MW', 'NE', 'NE', 'W', 'SPA', 'W', 'MW', 'W', 'NE', 'NE', 'S', 'NE', 'S', 'S', 'W', 'W', 'S', 'NE', 'W', 'UK', 'W', 'NE', 'S', 'W', 'W', 'NE', 'NE', 'S', 'S', 'NE', 'NE', 'NE', 'NE', 'W', 'NE', 'S', 'W', 'NE', 'S', 'NE', 'JAM', 'S', 'NE', 'FRA', 'W', 'NE', 'NE', 'NE', 'S', 'W', 'MW', 'NE', 'MW', 'NE', 'W', 'NE', 'MW', 'W', 'W', 'NE', 'NE', 'S', 'W', 'NE', 'S', 'W', 'S', 'W', 'NE', 'S', 'NE', 'NE', 'NE', 'UK', 'NE', 'MW', 'W', 'NE', 'NE', 'W', 'W', 'NE', 'MW', 'NE', 'NE', 'UK', 'NE', 'NE/W', 'NE', 'MW', 'W', 'S')

getwd()
# データを読み込む
clusters4_data <- read.csv("basedlist_forr.csv")
# summary を表示
summary(clusters4_data)
# データにアクセスするために attach
attach(clusters4_data)
#Basedlist 列からデータを抽出
vector <- clusters4_data$Basedlist
# "No results" を削除
vector_cleaned <- vector[vector != "No results"]
# 結果を確認
print(vector_cleaned)


clusters4 <- c(vector_cleaned)

group3 <- unlist(clusters3)
group4 <- unlist(clusters4)

# 頻度表の作成
table3 <- table(factor(group3, levels = regions))
table4 <- table(factor(group4, levels = regions))

# クロス表の作成
cross_table3 <- rbind(table3, table4)


# フィッシャーの正確検定の実行（データが少ない場合）
fisher_result3 <- fisher.test(cross_table3, simulate.p.value=TRUE)

# 結果の出力
print(cross_table)
print(fisher_result3)